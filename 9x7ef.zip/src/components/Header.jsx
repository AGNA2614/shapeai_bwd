import React from "react";
import App from "./App";
function Header() {
  return (
    <header>
      <h1>ShapeAI</h1>
    </header>
  );
}
export default Header;
